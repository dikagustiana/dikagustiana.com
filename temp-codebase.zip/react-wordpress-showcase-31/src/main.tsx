import React from 'react'
import { createRoot } from 'react-dom/client'
import { RoleProvider } from './contexts/RoleContext'
import App from './App.tsx'
import './index.css'

// #region agent log
fetch('http://127.0.0.1:7242/ingest/16ee499c-af8d-4628-9b24-790c92c7e646', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    sessionId: 'debug-session',
    runId: 'run1',
    hypothesisId: 'B',
    location: 'src/main.tsx:7',
    message: 'main render start',
    data: {
      rootExists: !!document.getElementById("root"),
      path: window.location.pathname
    },
    timestamp: Date.now()
  })
}).catch(() => {});
// #endregion

createRoot(document.getElementById("root")!).render(
  <RoleProvider>
    <App />
  </RoleProvider>
);
