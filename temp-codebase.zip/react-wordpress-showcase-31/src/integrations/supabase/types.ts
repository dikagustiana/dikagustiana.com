export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.4"
  }
  public: {
    Tables: {
      books_uploads: {
        Row: {
          author: string | null
          category: string
          cover_color: string | null
          cover_height: number | null
          cover_path: string | null
          cover_width: number | null
          deleted_at: string | null
          filename: string
          filepath: string
          id: string
          mime_type: string
          size_bytes: number
          tags: string[] | null
          title: string | null
          uploaded_at: string
          uploaded_by: string
          version: number
          year: number | null
        }
        Insert: {
          author?: string | null
          category: string
          cover_color?: string | null
          cover_height?: number | null
          cover_path?: string | null
          cover_width?: number | null
          deleted_at?: string | null
          filename: string
          filepath: string
          id?: string
          mime_type: string
          size_bytes: number
          tags?: string[] | null
          title?: string | null
          uploaded_at?: string
          uploaded_by: string
          version?: number
          year?: number | null
        }
        Update: {
          author?: string | null
          category?: string
          cover_color?: string | null
          cover_height?: number | null
          cover_path?: string | null
          cover_width?: number | null
          deleted_at?: string | null
          filename?: string
          filepath?: string
          id?: string
          mime_type?: string
          size_bytes?: number
          tags?: string[] | null
          title?: string | null
          uploaded_at?: string
          uploaded_by?: string
          version?: number
          year?: number | null
        }
        Relationships: []
      }
      embeds: {
        Row: {
          created_at: string | null
          created_by: string
          height: number | null
          id: string
          page_id: string
          scrollable: boolean | null
          src: string
          title: string | null
          type: string
          width: number | null
        }
        Insert: {
          created_at?: string | null
          created_by: string
          height?: number | null
          id?: string
          page_id: string
          scrollable?: boolean | null
          src: string
          title?: string | null
          type: string
          width?: number | null
        }
        Update: {
          created_at?: string | null
          created_by?: string
          height?: number | null
          id?: string
          page_id?: string
          scrollable?: boolean | null
          src?: string
          title?: string | null
          type?: string
          width?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "embeds_page_id_fkey"
            columns: ["page_id"]
            isOneToOne: false
            referencedRelation: "fsli_pages"
            referencedColumns: ["id"]
          },
        ]
      }
      fsli_inline_assets: {
        Row: {
          alt_text: string | null
          caption: string | null
          file_name: string
          id: string
          mime_type: string
          page_key: string
          size_bytes: number
          storage_path: string
          uploaded_at: string
          uploaded_by: string | null
        }
        Insert: {
          alt_text?: string | null
          caption?: string | null
          file_name: string
          id?: string
          mime_type: string
          page_key: string
          size_bytes: number
          storage_path: string
          uploaded_at?: string
          uploaded_by?: string | null
        }
        Update: {
          alt_text?: string | null
          caption?: string | null
          file_name?: string
          id?: string
          mime_type?: string
          page_key?: string
          size_bytes?: number
          storage_path?: string
          uploaded_at?: string
          uploaded_by?: string | null
        }
        Relationships: []
      }
      fsli_inline_embeds: {
        Row: {
          embed_type: string
          embed_url: string | null
          height_px: number | null
          id: string
          meta: Json | null
          page_key: string
          provider: string | null
          range_ref: string | null
          section_key: string
          storage_path: string | null
          updated_at: string
        }
        Insert: {
          embed_type: string
          embed_url?: string | null
          height_px?: number | null
          id?: string
          meta?: Json | null
          page_key: string
          provider?: string | null
          range_ref?: string | null
          section_key: string
          storage_path?: string | null
          updated_at?: string
        }
        Update: {
          embed_type?: string
          embed_url?: string | null
          height_px?: number | null
          id?: string
          meta?: Json | null
          page_key?: string
          provider?: string | null
          range_ref?: string | null
          section_key?: string
          storage_path?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      fsli_inline_sections: {
        Row: {
          content_html: string
          id: string
          page_key: string
          section_key: string
          updated_at: string
          updated_by: string | null
          version: number
        }
        Insert: {
          content_html?: string
          id?: string
          page_key: string
          section_key: string
          updated_at?: string
          updated_by?: string | null
          version?: number
        }
        Update: {
          content_html?: string
          id?: string
          page_key?: string
          section_key?: string
          updated_at?: string
          updated_by?: string | null
          version?: number
        }
        Relationships: []
      }
      fsli_metrics: {
        Row: {
          id: string
          label: string
          page_id: string
          sort_order: number | null
          unit: string | null
          updated_at: string | null
          value: number | null
        }
        Insert: {
          id?: string
          label: string
          page_id: string
          sort_order?: number | null
          unit?: string | null
          updated_at?: string | null
          value?: number | null
        }
        Update: {
          id?: string
          label?: string
          page_id?: string
          sort_order?: number | null
          unit?: string | null
          updated_at?: string | null
          value?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "fsli_metrics_page_id_fkey"
            columns: ["page_id"]
            isOneToOne: false
            referencedRelation: "fsli_pages"
            referencedColumns: ["id"]
          },
        ]
      }
      fsli_pages: {
        Row: {
          created_at: string | null
          id: string
          notes_ref: string | null
          slug: string
          subtitle: string | null
          title: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          notes_ref?: string | null
          slug: string
          subtitle?: string | null
          title: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          notes_ref?: string | null
          slug?: string
          subtitle?: string | null
          title?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      fsli_revisions: {
        Row: {
          content: Json
          created_at: string | null
          editor_id: string
          id: string
          page_id: string
          section_id: string | null
        }
        Insert: {
          content: Json
          created_at?: string | null
          editor_id: string
          id?: string
          page_id: string
          section_id?: string | null
        }
        Update: {
          content?: Json
          created_at?: string | null
          editor_id?: string
          id?: string
          page_id?: string
          section_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fsli_revisions_page_id_fkey"
            columns: ["page_id"]
            isOneToOne: false
            referencedRelation: "fsli_pages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fsli_revisions_section_id_fkey"
            columns: ["section_id"]
            isOneToOne: false
            referencedRelation: "fsli_sections"
            referencedColumns: ["id"]
          },
        ]
      }
      fsli_sections: {
        Row: {
          content: Json
          id: string
          key: string
          page_id: string
          sort_order: number | null
          updated_at: string | null
        }
        Insert: {
          content: Json
          id?: string
          key: string
          page_id: string
          sort_order?: number | null
          updated_at?: string | null
        }
        Update: {
          content?: Json
          id?: string
          key?: string
          page_id?: string
          sort_order?: number | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fsli_sections_page_id_fkey"
            columns: ["page_id"]
            isOneToOne: false
            referencedRelation: "fsli_pages"
            referencedColumns: ["id"]
          },
        ]
      }
      green_essays: {
        Row: {
          author_name: string
          content_html: string | null
          content_json: Json | null
          cover_image_url: string | null
          created_at: string
          id: string
          reading_time: number | null
          section: string
          slug: string
          status: string
          subtitle: string | null
          title: string
          updated_at: string
          updated_by: string | null
          version: number
        }
        Insert: {
          author_name?: string
          content_html?: string | null
          content_json?: Json | null
          cover_image_url?: string | null
          created_at?: string
          id?: string
          reading_time?: number | null
          section: string
          slug: string
          status?: string
          subtitle?: string | null
          title?: string
          updated_at?: string
          updated_by?: string | null
          version?: number
        }
        Update: {
          author_name?: string
          content_html?: string | null
          content_json?: Json | null
          cover_image_url?: string | null
          created_at?: string
          id?: string
          reading_time?: number | null
          section?: string
          slug?: string
          status?: string
          subtitle?: string | null
          title?: string
          updated_at?: string
          updated_by?: string | null
          version?: number
        }
        Relationships: []
      }
      green_essays_templates: {
        Row: {
          content_html: string | null
          content_json: Json | null
          created_at: string
          id: string
          section: string
          title_template: string
        }
        Insert: {
          content_html?: string | null
          content_json?: Json | null
          created_at?: string
          id?: string
          section: string
          title_template?: string
        }
        Update: {
          content_html?: string | null
          content_json?: Json | null
          created_at?: string
          id?: string
          section?: string
          title_template?: string
        }
        Relationships: []
      }
      green_essays_versions: {
        Row: {
          content_html: string | null
          content_json: Json | null
          created_at: string
          created_by: string | null
          essay_id: string
          id: string
          subtitle: string | null
          title: string
          version: number
          version_note: string | null
        }
        Insert: {
          content_html?: string | null
          content_json?: Json | null
          created_at?: string
          created_by?: string | null
          essay_id: string
          id?: string
          subtitle?: string | null
          title: string
          version: number
          version_note?: string | null
        }
        Update: {
          content_html?: string | null
          content_json?: Json | null
          created_at?: string
          created_by?: string | null
          essay_id?: string
          id?: string
          subtitle?: string | null
          title?: string
          version?: number
          version_note?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "green_essays_versions_essay_id_fkey"
            columns: ["essay_id"]
            isOneToOne: false
            referencedRelation: "green_essays"
            referencedColumns: ["id"]
          },
        ]
      }
      ops_edit_log: {
        Row: {
          action: string
          essay_id: string
          id: string
          timestamp: string
          user_email: string
        }
        Insert: {
          action: string
          essay_id: string
          id?: string
          timestamp?: string
          user_email: string
        }
        Update: {
          action?: string
          essay_id?: string
          id?: string
          timestamp?: string
          user_email?: string
        }
        Relationships: [
          {
            foreignKeyName: "ops_edit_log_essay_id_fkey"
            columns: ["essay_id"]
            isOneToOne: false
            referencedRelation: "green_essays"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string | null
          display_name: string | null
          email: string
          id: string
          role: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          display_name?: string | null
          email: string
          id: string
          role?: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          display_name?: string | null
          email?: string
          id?: string
          role?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          email: string | null
          id: string
          role: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          email?: string | null
          id?: string
          role?: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          email?: string | null
          id?: string
          role?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      calculate_reading_time: {
        Args: { content_text: string }
        Returns: number
      }
      get_current_user_role: {
        Args: Record<PropertyKey, never>
        Returns: string
      }
      get_user_role: {
        Args: Record<PropertyKey, never>
        Returns: string
      }
      is_admin: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
      is_admin_or_editor: {
        Args: { uid: string }
        Returns: boolean
      }
      is_admin_user: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
      set_admin_by_email: {
        Args: { user_email: string }
        Returns: undefined
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
