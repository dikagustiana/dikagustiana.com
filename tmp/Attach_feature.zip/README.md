
  # Attach feature

  This is a code bundle for Attach feature. The original project is available at https://www.figma.com/design/LcFgarOfShuiibg5X7vPJc/Attach-feature.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  