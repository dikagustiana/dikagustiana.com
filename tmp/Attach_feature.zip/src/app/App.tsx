import React from 'react';
import { Shield, PieChart, Building2, BookOpen, Layers, TrendingUp, Target, FileSpreadsheet } from 'lucide-react';
import { ConceptPanel } from './components/ConceptPanel';
import { ProcessStep } from './components/ProcessStep';
import { AccountRow } from './components/AccountRow';

export default function App() {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Navigation Bar */}
      <nav className="bg-slate-900 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Building2 className="w-6 h-6 text-emerald-400" strokeWidth={1.5} />
              <span className="text-white font-semibold tracking-tight">Friendly learning buddy</span>
              <span className="ml-2 px-2 py-0.5 bg-emerald-600 text-white text-xs font-semibold rounded">ADMIN</span>
            </div>
            <div className="flex items-center gap-6 text-sm">
              <a href="#" className="text-slate-300 hover:text-white transition-colors">Home</a>
              <a href="#" className="text-slate-300 hover:text-white transition-colors">Finance Workspace</a>
              <a href="#" className="text-slate-300 hover:text-white transition-colors">Accounting</a>
              <a href="#" className="text-white font-medium">Consolidated Reporting</a>
              <a href="#" className="text-slate-300 hover:text-white transition-colors">Learning</a>
            </div>
          </div>
        </div>
      </nav>

      {/* Breadcrumb */}
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-8 py-3">
          <div className="flex items-center gap-2 text-xs text-slate-600">
            <span>Home</span>
            <span className="text-slate-400">/</span>
            <span>Accounting</span>
            <span className="text-slate-400">/</span>
            <span className="text-slate-900 font-medium">Consolidated Reporting</span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-8 py-12">
        {/* Hero Header Section */}
        <header className="mb-16">
          <h1 className="text-4xl font-bold text-slate-900 mb-3 tracking-tight">
            Consolidated Reporting
          </h1>
          <p className="text-slate-600 text-base leading-relaxed max-w-3xl">
            How group financial statements are constructed under PSAK 65 and IFRS 10.
          </p>
          <div className="w-full h-px bg-slate-300 mt-6"></div>
        </header>

        {/* Concept Framework Row */}
        <section className="mb-16">
          <div className="grid grid-cols-3 gap-6">
            <ConceptPanel
              title="Control"
              definition="You consolidate entities you control. Control usually means more than 50% voting rights but can exist with less if you have contractual power over key decisions."
              icon={Shield}
            />
            <ConceptPanel
              title="Non-Controlling Interest"
              definition="If you own 51% of a subsidiary, you consolidate 100% of its results. The 49% you do not own is shown as NCI — a separate line in equity."
              icon={PieChart}
              diagram={
                <div className="flex items-center gap-2 text-xs">
                  <div className="flex-1 bg-slate-900 h-2"></div>
                  <span className="text-slate-500 font-mono">51%</span>
                  <div className="flex-1 bg-slate-300 h-2"></div>
                  <span className="text-slate-500 font-mono">49%</span>
                </div>
              }
            />
            <ConceptPanel
              title="Goodwill"
              definition="The excess of what you paid over the fair value acquired. Represents future economic benefits not separately identifiable."
              icon={TrendingUp}
              diagram={
                <div className="text-[11px] font-mono text-slate-600 space-y-1">
                  <div>Price Paid − Net Assets = Goodwill</div>
                </div>
              }
            />
          </div>
        </section>

        {/* Process Architecture Section */}
        <section className="mb-16">
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-slate-900 mb-2">Process Architecture</h2>
            <p className="text-sm text-slate-600">The five-step technical workflow</p>
          </div>
          
          <div className="bg-white border border-slate-200 p-8">
            <div className="grid grid-cols-5 gap-6">
              <ProcessStep
                stepNumber={1}
                title="Individual Books"
                description="Each entity maintains its own complete set of financial statements independently."
                icon={BookOpen}
              />
              <ProcessStep
                stepNumber={2}
                title="Combine Financials"
                description="All entity statements are aggregated line by line into a combined total."
                icon={Layers}
              />
              <ProcessStep
                stepNumber={3}
                title="Eliminate Intercompany"
                description="Remove all internal transactions between entities to avoid double counting."
                icon={Target}
              />
              <ProcessStep
                stepNumber={4}
                title="Allocate NCI"
                description="The portion of equity and profit shareholders do not own is separated and disclosed."
                icon={PieChart}
              />
              <ProcessStep
                stepNumber={5}
                title="Consolidated Output"
                description="The final statement shows the group as a single economic entity."
                icon={FileSpreadsheet}
                isLast
              />
            </div>
          </div>
        </section>

        {/* Working Paper Simulation Section */}
        <section className="mb-12">
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-slate-900 mb-2">Consolidation Working Paper Simulation</h2>
            <p className="text-sm text-slate-600">PT Qaumty C and Subsidiaries — Consolidated Statement of Financial Position — December 31, 2024</p>
          </div>

          <div className="bg-white border border-slate-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b-2 border-slate-300">
                    <th className="text-left text-[10px] font-semibold text-slate-500 uppercase tracking-wider py-3 px-3">
                      Account
                    </th>
                    <th colSpan={4} className="text-center text-[10px] font-semibold text-slate-500 uppercase tracking-wider py-3 px-3 border-l border-slate-200">
                      <div className="mb-2">Individual Entities</div>
                      <div className="grid grid-cols-4 gap-2 text-[9px] font-medium">
                        <div>Qaumty C</div>
                        <div>Qaumty D</div>
                        <div>Qaumty E</div>
                        <div>Qaumty F</div>
                      </div>
                    </th>
                    <th className="text-center text-[10px] font-semibold text-slate-500 uppercase tracking-wider py-3 px-3 bg-slate-50/50 border-l border-slate-200">
                      Combined
                    </th>
                    <th className="text-center text-[10px] font-semibold text-slate-500 uppercase tracking-wider py-3 px-3 bg-amber-50/30 border-l border-slate-200">
                      Eliminations
                    </th>
                    <th className="text-center text-[10px] font-semibold text-slate-500 uppercase tracking-wider py-3 px-3 bg-emerald-50/40 border-l border-slate-200">
                      Consolidated
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <AccountRow account="ASSETS" entities={['', '', '', '']} isHeader />
                  <AccountRow account="CURRENT ASSETS" entities={['', '', '', '']} isHeader />
                  <AccountRow account="Cash and cash equivalents" entities={[45000, 12000, 8500, 6200]} combined={71700} elimination="—" consolidated={71700} indent={1} />
                  <AccountRow account="Trade Receivables — Third Parties" entities={[28000, 15000, 9000, 4500]} combined={56500} elimination="—" consolidated={56500} indent={1} />
                  <AccountRow account="Trade Receivables — Related Parties" entities={[12000, 8000, 5000, 3000]} combined={28000} elimination="(28000)" consolidated="—" indent={1} />
                  <AccountRow account="Unbilled — Third Parties" entities={['—', '—', '—', '—']} combined="—" elimination="—" consolidated="—" indent={1} />
                  <AccountRow account="Current portion of lease receivables" entities={['—', '—', '—', '—']} combined="—" elimination="—" consolidated="—" indent={1} />
                  <AccountRow account="Employee Receivables" entities={['—', '—', '—', '—']} combined="—" elimination="—" consolidated="—" indent={1} />
                  <AccountRow account="Loan Receivables — Third Parties" entities={['—', '—', '—', '—']} combined="—" elimination="—" consolidated="—" indent={1} />
                  <AccountRow account="Loan Receivables — Related Parties" entities={['—', '—', '—', '—']} combined="—" elimination="—" consolidated="—" indent={1} />
                  <AccountRow account="Other Receivables — Third Parties" entities={['—', '—', '—', '—']} combined="—" elimination="—" consolidated="—" indent={1} />
                  <AccountRow account="Other Receivables — Related Parties" entities={['—', '—', '—', '—']} combined="—" elimination="—" consolidated="—" indent={1} />
                  <AccountRow account="Inventories" entities={['—', '—', '—', '—']} combined="—" elimination="—" consolidated="—" indent={1} />
                  <AccountRow account="Prepaid Tax" entities={['—', '—', '—', '—']} combined="—" elimination="—" consolidated="—" indent={1} />
                  <AccountRow account="Prepayment and Advances" entities={['—', '—', '—', '—']} combined="—" elimination="—" consolidated="—" indent={1} />
                  <AccountRow account="Restricted Cash and Time Deposits" entities={['—', '—', '—', '—']} combined="—" elimination="—" consolidated="—" indent={1} />
                  <AccountRow account="Other Current Assets" entities={['—', '—', '—', '—']} combined="—" elimination="—" consolidated="—" indent={1} />
                  <AccountRow account="TOTAL CURRENT ASSETS" entities={[85000, 35000, 22500, 13700]} combined={156200} elimination="(28000)" consolidated={128200} isSubtotal />
                  
                  <AccountRow account="NON-CURRENT ASSETS" entities={['', '', '', '']} isHeader />
                  <AccountRow account="Investment in Subsidiaries" entities={[125000, '—', '—', '—']} combined={125000} elimination="(125000)" consolidated="—" indent={1} />
                  <AccountRow account="Deferred Investment" entities={['—', '—', '—', '—']} combined="—" elimination="—" consolidated="—" indent={1} />
                  <AccountRow account="Fixed Assets" entities={[85000, 45000, 28000, 15000]} combined={173000} elimination="—" consolidated={173000} indent={1} />
                  <AccountRow account="Intangible Assets" entities={[12000, 5000, 3000, 1500]} combined={21500} elimination="—" consolidated={21500} indent={1} />
                  <AccountRow account="Right of Use Asset" entities={['—', '—', '—', '—']} combined="—" elimination="—" consolidated="—" indent={1} />
                  <AccountRow account="Other Non-Current Assets" entities={['—', '—', '—', '—']} combined="—" elimination="—" consolidated="—" indent={1} />
                  <AccountRow account="TOTAL NON-CURRENT ASSETS" entities={[222000, 50000, 31000, 16500]} combined={319500} elimination="(125000)" consolidated={194500} isSubtotal />
                  <AccountRow account="TOTAL ASSETS" entities={[307000, 85000, 53500, 30200]} combined={475700} elimination="(153000)" consolidated={322700} isSubtotal />
                  
                  <AccountRow account="LIABILITIES" entities={['', '', '', '']} isHeader />
                  <AccountRow account="CURRENT LIABILITIES" entities={['', '', '', '']} isHeader />
                  <AccountRow account="To be defined" entities={['—', '—', '—', '—']} combined="—" elimination="—" consolidated="—" indent={1} />
                  <AccountRow account="To be defined" entities={['—', '—', '—', '—']} combined="—" elimination="—" consolidated="—" indent={1} />
                </tbody>
              </table>
            </div>
          </div>
        </section>

        {/* Insight Panel */}
        <section className="mb-16">
          <div className="bg-white border-l-4 border-emerald-600 p-6">
            <h3 className="text-sm font-semibold text-slate-900 uppercase tracking-wider mb-4">
              Why Consolidation Matters
            </h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-3 text-sm text-slate-700">
                <span className="text-emerald-600 font-bold mt-0.5">•</span>
                <span>Prevents double counting of intercompany transactions and balances</span>
              </li>
              <li className="flex items-start gap-3 text-sm text-slate-700">
                <span className="text-emerald-600 font-bold mt-0.5">•</span>
                <span>Separates ownership from control, showing the group's true economic substance</span>
              </li>
              <li className="flex items-start gap-3 text-sm text-slate-700">
                <span className="text-emerald-600 font-bold mt-0.5">•</span>
                <span>Reveals true group capital structure and financial position for stakeholders</span>
              </li>
            </ul>
          </div>
        </section>
      </div>
    </div>
  );
}
