import React from 'react';

interface AccountRowProps {
  account: string;
  entities: (string | number)[];
  combined?: string | number;
  elimination?: string | number;
  consolidated?: string | number;
  isHeader?: boolean;
  isSubtotal?: boolean;
  indent?: number;
}

export function AccountRow({ 
  account, 
  entities, 
  combined, 
  elimination, 
  consolidated, 
  isHeader = false,
  isSubtotal = false,
  indent = 0
}: AccountRowProps) {
  const baseClasses = "text-xs py-2.5 border-b border-slate-100";
  const textClasses = isHeader 
    ? "font-semibold text-slate-900 uppercase text-[11px] tracking-wide" 
    : isSubtotal 
    ? "font-semibold text-slate-900"
    : "text-slate-700";
  
  return (
    <tr className={isHeader ? "bg-slate-50" : ""}>
      <td className={`${baseClasses} ${textClasses} pr-4`} style={{ paddingLeft: `${0.75 + indent * 0.75}rem` }}>
        {account}
      </td>
      {entities.map((value, idx) => (
        <td key={idx} className={`${baseClasses} ${textClasses} text-right px-3`}>
          {value || '—'}
        </td>
      ))}
      <td className={`${baseClasses} ${textClasses} text-right px-3 bg-slate-50/50`}>
        {combined || '—'}
      </td>
      <td className={`${baseClasses} ${textClasses} text-right px-3 bg-amber-50/30`}>
        {elimination || '—'}
      </td>
      <td className={`${baseClasses} ${textClasses} text-right px-3 bg-emerald-50/40`}>
        {consolidated || '—'}
      </td>
    </tr>
  );
}
