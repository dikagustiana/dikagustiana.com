import React from 'react';
import { LucideIcon } from 'lucide-react';

interface ConceptPanelProps {
  title: string;
  definition: string;
  icon: LucideIcon;
  diagram?: React.ReactNode;
}

export function ConceptPanel({ title, definition, icon: Icon, diagram }: ConceptPanelProps) {
  return (
    <div className="border border-slate-200 bg-white p-6">
      <div className="flex items-start gap-3 mb-3">
        <div className="p-2 bg-slate-50 border border-slate-200">
          <Icon className="w-5 h-5 text-slate-700" strokeWidth={1.5} />
        </div>
        <h3 className="uppercase tracking-wider text-xs font-semibold text-slate-900 mt-2">
          {title}
        </h3>
      </div>
      <p className="text-sm text-slate-600 leading-relaxed mb-4">
        {definition}
      </p>
      {diagram && (
        <div className="mt-4">
          {diagram}
        </div>
      )}
    </div>
  );
}
