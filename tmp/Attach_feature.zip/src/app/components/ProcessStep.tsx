import React from 'react';
import { LucideIcon } from 'lucide-react';

interface ProcessStepProps {
  stepNumber: number;
  title: string;
  description: string;
  icon: LucideIcon;
  isLast?: boolean;
}

export function ProcessStep({ stepNumber, title, description, icon: Icon, isLast }: ProcessStepProps) {
  return (
    <div className="flex items-start gap-4">
      <div className="flex-1">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-12 h-12 border-2 border-slate-300 bg-white flex items-center justify-center">
            <Icon className="w-6 h-6 text-emerald-700" strokeWidth={1.5} />
          </div>
          <div className="flex-1">
            <div className="text-xs font-semibold text-slate-500 mb-1">STEP {stepNumber}</div>
            <h4 className="font-semibold text-slate-900">{title}</h4>
          </div>
        </div>
        <p className="text-xs text-slate-600 leading-relaxed ml-15">
          {description}
        </p>
      </div>
      {!isLast && (
        <div className="flex items-center pt-6">
          <svg width="24" height="2" viewBox="0 0 24 2" className="text-slate-300">
            <line x1="0" y1="1" x2="24" y2="1" stroke="currentColor" strokeWidth="1" />
            <polygon points="20,0 24,1 20,2" fill="currentColor" />
          </svg>
        </div>
      )}
    </div>
  );
}
