You are a senior product designer working on a finance-focused think tank website. The tone must feel institutional, analytical, and intellectually premium. Not academic. Not playful. Not startup SaaS.

Redesign the “Consolidated Reporting” subsection.

Design Objective
Make it feel like a board-level consolidation engine walkthrough. It should communicate financial control, technical depth, and clarity.

Overall Style Direction
• Clean light background, not dark
• Structured grid layout
• Strong typographic hierarchy
• High contrast titles
• Thin separators
• Subtle finance color accents: deep navy, muted emerald, soft gray
• No rounded playful cards
• Sharp edges or very light radius
• Professional spacing

Section Structure Redesign

Hero Header Section

Left aligned.

Large Title:
Consolidated Reporting

Short executive subtitle:
How group financial statements are constructed under PSAK 65 and IFRS 10.

Add a thin underline divider below header for authority.

Concept Framework Row

Replace current 3 generic boxes with structured horizontal panels.

Three panels aligned horizontally:

CONTROL
Short definition
Add subtle icon related to governance

NON CONTROLLING INTEREST
Short definition
Include visual equity split bar

GOODWILL
Short definition
Add acquisition equation micro-diagram

Panels must feel analytical. No pastel colors.

Process Architecture Section

Instead of small circular icons, create a structured 5-step horizontal flow diagram.

Step 1 Individual Books
Step 2 Combine Financials
Step 3 Eliminate Intercompany
Step 4 Allocate NCI
Step 5 Consolidated Output

Use clean linear connectors.
Add micro explanation under each step.
Make this section visually stronger than current one.

This is the core intellectual section.

Working Paper Simulation Section

Title:
Consolidation Working Paper Simulation

Design this as a structured financial grid preview, not a flat spreadsheet screenshot.

Layout:

Left: Account classification column
Middle: Individual Entities columns
Next: Combined column
Next: Elimination column (slightly tinted light gray)
Right: Consolidated column (subtle green highlight)

Add small label badges above columns:
INDIVIDUAL
COMBINED
ELIMINATION
CONSOLIDATED

It must look like a financial system, not Excel copy paste.

Add an “Insight Panel”

Below the table add a narrow horizontal section titled:

Why Consolidation Matters

Include 3 sharp bullet insights:

• Prevents double counting
• Separates ownership from control
• Reveals true group capital structure

Design this with subtle left border accent.

Typography Rules

Headings: Serif or strong modern sans serif
Body: Clean professional sans
No playful fonts
No decorative effects

Spacing

Generous white space between sections
Clear vertical rhythm
Consistent column alignment

Tone

It must feel like:
Big 4 technical note meets institutional investment memo.